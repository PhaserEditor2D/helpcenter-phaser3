// Type definitions for codemirror
// Project: https://github.com/marijnh/CodeMirror
// Definitions by: mihailik <https://github.com/mihailik>
//                 nrbernard <https://github.com/nrbernard>
//                 Pr1st0n <https://github.com/Pr1st0n>
//                 rileymiller <https://github.com/rileymiller>
//                 toddself <https://github.com/toddself>
//                 ysulyma <https://github.com/ysulyma>
//                 azoson <https://github.com/azoson>
//                 kylesferrazza <https://github.com/kylesferrazza>
//                 fityocsaba96 <https://github.com/fityocsaba96>
//                 koddsson <https://github.com/koddsson>
//                 ficristo <https://github.com/ficristo>
// Definitions: https://github.com/DefinitelyTyped/DefinitelyTyped
// TypeScript Version: 3.2
